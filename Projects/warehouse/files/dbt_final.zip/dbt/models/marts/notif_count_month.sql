{{ config(materialized='table') }}

-- monthly count of rollout-related notifications per org, Jan 2026 onward.

WITH rollout_events AS (
  SELECT
    org_id::integer AS org_key,
    sent_at,
    event_type
  FROM {{ ref('stg_notifications__events') }}
  WHERE (
        event_type LIKE 'rollout\_%'   ESCAPE '\'
     OR event_type LIKE 'rollback\_%'  ESCAPE '\'
     OR event_type LIKE 'threshold\_%' ESCAPE '\'
  )
    AND sent_at >= TIMESTAMP '2026-01-01'
),

-- get the month_start for each event, then aggregate counts by org and month_start
monthly_counts AS (
  SELECT
    org_key,
    DATE_TRUNC('month', sent_at)::date AS month_start,
    COUNT(*) AS rollout_notif_count
  FROM rollout_events
  GROUP BY org_key, DATE_TRUNC('month', sent_at)::date
)

-- join with dim_date to get month_end_date and year_month

SELECT
  d.date_key,
  d.date AS month_end_date,
  d.year_month,
  m.org_key,
  m.rollout_notif_count
FROM monthly_counts m
JOIN {{ ref('dim_date') }} d
  ON d.month_start = m.month_start
 AND d.date = (d.month_start + INTERVAL '1 month' - INTERVAL '1 day')::date
