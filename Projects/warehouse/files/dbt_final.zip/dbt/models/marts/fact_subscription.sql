{{ config(materialized='table') }}

-- monthly snapshot: one row per active subscription per month-end, Jan 2026+
-- plan and seats reconstructed from the change log

WITH changes AS (
  SELECT
    sub_id,
    org_id,
    change_type,
    to_plan_id,
    to_seats,
    changed_at::date AS changed_date,
    changed_at
  FROM {{ ref('stg_billing__subscription_changes') }}
),

month_ends AS (
  SELECT
    date_key,
    date         AS month_end_date,
    year_month
  FROM {{ ref('dim_date') }}
  WHERE date = (month_start + INTERVAL '1 month' - INTERVAL '1 day')::date
    AND date >= DATE '2026-01-31'
    AND month_start <= (
      SELECT DATE_TRUNC('month', MAX(changed_at))::date FROM changes
    )
),

subs AS (
  SELECT DISTINCT sub_id, org_id FROM changes
),

subs_x_months AS (
  SELECT
    s.sub_id,
    s.org_id,
    m.date_key,
    m.month_end_date,
    m.year_month
  FROM subs s
  CROSS JOIN month_ends m
),

sub_state AS (
  SELECT
    sxm.sub_id,
    sxm.org_id,
    sxm.date_key,
    sxm.month_end_date,
    sxm.year_month,
    EXISTS (
      SELECT 1 FROM changes c
      WHERE c.sub_id = sxm.sub_id
        AND c.change_type = 'created'
        AND c.changed_date <= sxm.month_end_date
    ) AS is_created_by_month_end,
    EXISTS (
      SELECT 1 FROM changes c
      WHERE c.sub_id = sxm.sub_id
        AND c.change_type = 'cancelled'
        AND c.changed_date <= sxm.month_end_date
    ) AS is_cancelled_by_month_end,
    -- most recent plan on or before month-end
    (
      SELECT c.to_plan_id
      FROM changes c
      WHERE c.sub_id = sxm.sub_id
        AND c.change_type IN ('created', 'plan_changed')
        AND c.changed_date <= sxm.month_end_date
      ORDER BY c.changed_at DESC
      LIMIT 1
    ) AS plan_id_at_month_end,
    -- most recent seats on or before month-end
    (
      SELECT c.to_seats
      FROM changes c
      WHERE c.sub_id = sxm.sub_id
        AND c.to_seats IS NOT NULL
        AND c.changed_date <= sxm.month_end_date
      ORDER BY c.changed_at DESC
      LIMIT 1
    ) AS seats_at_month_end
  FROM subs_x_months sxm
),

plan_prices AS (
  SELECT plan_id AS plan_key, monthly_price_cents / 100.0 AS monthly_price
  FROM {{ ref('stg_billing__plans') }}
)

SELECT
  s.sub_id,
  s.org_id                   AS org_key,
  s.plan_id_at_month_end     AS plan_key,
  s.date_key,
  s.month_end_date,
  s.year_month,
  s.seats_at_month_end       AS seats,
  s.seats_at_month_end * p.monthly_price AS mrr_amount
FROM sub_state s
JOIN plan_prices p ON p.plan_key = s.plan_id_at_month_end
WHERE s.is_created_by_month_end
  AND NOT s.is_cancelled_by_month_end
  AND s.plan_id_at_month_end IS NOT NULL
