{{ config(materialized='table') }}

-- one row per plan

SELECT
  plan_id                                  AS plan_key,
  plan_tier                                AS tier,
  monthly_price_cents / 100.0              AS monthly_price,
  plan_tier IN ('Pro', 'Enterprise')       AS is_proplus
FROM {{ ref('stg_billing__plans') }}
