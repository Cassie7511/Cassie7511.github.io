{{ config(materialized='table') }}

-- one row per org

SELECT
  org_id       AS org_key,
  org_name,
  industry,
  country,
  created_at
FROM {{ ref('stg_identity__orgs') }}
