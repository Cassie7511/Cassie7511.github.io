WITH
  april_pro_plus_orgs AS (
    SELECT DISTINCT
      f.org_key
    FROM
      marts_marts.fact_subscription f
      JOIN marts_marts.dim_plan p ON p.plan_key = f.plan_key
    WHERE
      f.date_key = 20260430
      AND p.is_proplus = TRUE
  ),
  orgs_with_rollout_activity AS (
    SELECT DISTINCT
      org_key
    FROM
      marts_marts.notif_count_month
    WHERE
      year_month BETWEEN '2026-01' AND '2026-04'
      AND rollout_notif_count > 0
  )
SELECT
  COUNT(DISTINCT a.org_key) AS pro_plus_orgs_april,
  COUNT(DISTINCT r.org_key) AS adopted_rollouts,
  ROUND(
    100.0 * COUNT(DISTINCT r.org_key) / NULLIF(COUNT(DISTINCT a.org_key), 0),
    1
  ) AS adoption_pct
FROM
  april_pro_plus_orgs a
  LEFT JOIN orgs_with_rollout_activity r ON r.org_key = a.org_key;
