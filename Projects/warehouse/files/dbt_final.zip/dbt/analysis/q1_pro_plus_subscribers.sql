-- Q1: count of Pro+ orgs at each month-end (Jan 2026 onward)
-- run in Metabase against Tracer Warehouse

SELECT
  f.year_month               AS month,
  COUNT(DISTINCT f.org_key)  AS pro_plus_orgs
FROM marts_marts.fact_subscription f
JOIN marts_marts.dim_plan p ON p.plan_key = f.plan_key
WHERE p.is_proplus = true
GROUP BY f.year_month
ORDER BY f.year_month;
