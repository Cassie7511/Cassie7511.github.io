SELECT
p.tier AS plan_tier,
f.year_month,
SUM(f.mrr_amount) AS total_mrr
FROM marts_marts.fact_subscription f
JOIN marts_marts.dim_plan p ON p.plan_key = f.plan_key
WHERE f.year_month >= '2026-01'
GROUP BY p.tier, f.year_month
ORDER BY f.year_month, p.tier;

